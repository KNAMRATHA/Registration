package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class Registration {
	@FindBy(name="fname")
	 public WebElement fname;
	
	@FindBy(name="lname")
	public WebElement lname;
	
	@FindBy(name="email")
	public WebElement email;
	
	@FindBy(name="contact")
	public WebElement contact;
	
	@FindBy(name="address")
	public WebElement address;
	
	@FindBy(name="city")
	public WebElement city;
	@FindBy(name="state")
	public WebElement state;
	
	
	@FindBy(how=How.ID,id="female")
	public WebElement female;
	@FindBy(how=How.ID,id="male")
	public WebElement male;
	@FindBy(how=How.ID,id="sing")
	public WebElement sing;
	@FindBy(how=How.ID,id="read")
	public WebElement read;
	@FindBy(how=How.ID,id="cook")
	public WebElement cook;
	@FindBy(name="submit")
	public WebElement submit;
	
	public String getSing() {
		return sing.getAttribute("value");
	}
	public void setSing() {
		this.sing.click();
	}
	public String getRead() {
		return read.getAttribute("value");
	}
	public void setRead() {
		this.read.click();
	}
	public String getCook() {
		return cook.getAttribute("value");
	}
	public void setCook( ) {
		this.cook.click();
	}
	public String getFemale() {
		return female.getAttribute("value");
	}
	public void setFemale() {
		this.female.click();
	}
	public String getMale() {
		return male.getAttribute("value");
	}
	public void setMale() {
		this.male.click();
	}
	public WebElement getState() {
		return state;
	}
	public void setState() {
		Select sel=new Select(state);
		sel.selectByVisibleText("Rajasthan");
	}
	
}
