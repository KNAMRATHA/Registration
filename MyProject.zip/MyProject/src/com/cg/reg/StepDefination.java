package com.cg.reg;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.cg.bean.NextPage;
import com.cg.bean.Registration;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {
	WebDriver driver;
	Registration registration;
	NextPage next;
	
	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("D:\\Practice\\SpringWebServices\\MyProject\\Index.html");
	    registration = PageFactory.initElements(driver, Registration.class);
	    
	}
	

@Given("^User wants to register$")
public void user_wants_to_register() throws Throwable {

	
}

@When("^user enters details$")
public void user_enters_details() throws Throwable {
	registration.fname.sendKeys("nam");
	registration.lname.sendKeys("kudu");
	registration.email.sendKeys("nam@gmail.com");
	registration.contact.sendKeys("7799421508");
	registration.address.sendKeys("Hyderabad");
	registration.city.sendKeys("Hyderabad");
//	By elements=By.name("gender");
//	List<WebElement> radio=driver.findElements(elements);
//	registration.gender.sendKeys();
//	WebElement radiobtn=radio.get(1);
//	radiobtn.click();
	//WebElement radio=driver.findElement(By.id("female"));
	//radio.click();
	registration.setFemale();
	//Select dropDown = new Select(registration.state);
	//dropDown.selectByValue("Rajasthan");
	registration.setState();
	//WebElement check1=driver.findElement(By.id("read"));
	//check1.click();
	//WebElement check2=driver.findElement(By.id("sing"));
	//check2.click();
	registration.setRead();
	registration.setSing();
	registration.submit.click();
	Alert jsAlert = driver.switchTo().alert();
	if(jsAlert.getText().equals("validated"))
	{
		Thread.sleep(1000);
		jsAlert.accept();
		driver.navigate().to("D:\\Practice\\SpringWebServices\\MyProject\\nextPage.html");
		next = PageFactory.initElements(driver, NextPage.class);
	}
	else
	{
		
	}
	
	   next.pdetails.sendKeys("J2EE project");
		next.pname.sendKeys("PARAM");
		next.client.sendKeys("HP");
		next.size.sendKeys("7");
		next.register.click();
}

@Then("^register that user$")
public void register_that_user() throws Throwable {
	driver.switchTo().alert().dismiss();
	  driver.get("D:\\success.html");
}

}
